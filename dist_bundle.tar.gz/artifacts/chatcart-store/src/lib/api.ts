export interface Seller {
  id: number;
  storeName: string | null;
  subdomain: string | null;
  whatsappNumber: string | null;
  bannerImageUrl: string | null;
  tagline: string | null;
  plan: string | null;
  productImageLayout: "square" | "portrait" | null;
  gstPercentage?: number | string | null;
  enableShipping?: boolean | null;
  shippingRatePerKg?: number | string | null;
  shippingAmountPerKgStep?: number | string | null;
}

export interface ProductImage {
  id: number;
  productId: number;
  url: string;
  displayOrder: number;
}

export interface ProductVariant {
  id: number;
  productId: number;
  label: string;
  options: string[];
}

export interface Product {
  id: number;
  sellerId: number;
  name: string;
  sku: string | null;
  description: string | null;
  price: number | null;
  status: string;
  categoryId: number | null;
  categoryIds?: number[];
  sortOrder: number;
  stockCount: number | null;
  showWhenOutOfStock: boolean;
  images: ProductImage[];
  variants: ProductVariant[];
}

export interface OrderItem {
  id: number;
  productNameSnapshot: string;
  priceSnapshot: number;
  variantSnapshot: string | null;
  productImageSnapshot: string | null;
  quantity: number;
  isSoldOut?: boolean;
  soldOutReason?: string | null;
}

export interface Order {
  id: string;
  status: string;
  subtotalAmount?: number;
  gstPercentage?: number;
  gstAmount?: number;
  shippingAmount?: number;
  shippingKg?: number;
  totalAmount: number;
  payableSubtotalAmount?: number;
  payableGstAmount?: number;
  payableShippingAmount?: number;
  payableShippingKg?: number;
  payableTotalAmount?: number;
  hasSoldOutItems?: boolean;
  customerContact: string | null;
  createdAt: string;
  sellerWhatsappNumber: string | null;
  sellerStoreName: string | null;
  sellerSubdomain: string | null;
  sellerBannerImageUrl: string | null;
  items: OrderItem[];
}

const BASE = "/api/public";

async function apiFetch<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${BASE}${path}`, {
    headers: { "Content-Type": "application/json" },
    ...init,
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error((body as { error?: string }).error ?? `HTTP ${res.status}`);
  }
  return res.json() as Promise<T>;
}

export interface Category {
  id: number;
  name: string;
  dozenDiscountPercent: number | null;
  bulkDiscountMinQty: number | null;
}

export const api = {
  getSeller: (subdomain: string) =>
    apiFetch<Seller>(`/sellers/${encodeURIComponent(subdomain)}`),

  getCategories: (subdomain: string) =>
    apiFetch<Category[]>(`/sellers/${encodeURIComponent(subdomain)}/categories`),

  getProducts: (subdomain: string) =>
    apiFetch<Product[]>(`/sellers/${encodeURIComponent(subdomain)}/products`),

  getProduct: (subdomain: string, productId: number) =>
    apiFetch<Product>(`/sellers/${encodeURIComponent(subdomain)}/products/${productId}`),

  createOrder: (body: {
    sellerId: number;
    customerContact?: string;
    items: Array<{
      productNameSnapshot: string;
      priceSnapshot: string;
      variantSnapshot?: string;
      productImageSnapshot?: string;
      quantity?: number;
    }>;
  }) =>
    apiFetch<Order>("/orders", {
      method: "POST",
      body: JSON.stringify(body),
    }),

  getOrder: (orderId: string) =>
    apiFetch<Order>(`/orders/${encodeURIComponent(orderId)}`),
};

export function imgSrc(storedUrl: string): string {
  return storedUrl.replace(/^\/objects\//, "/api/public/img/");
}

export function formatPrice(amount: number): string {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(amount);
}
