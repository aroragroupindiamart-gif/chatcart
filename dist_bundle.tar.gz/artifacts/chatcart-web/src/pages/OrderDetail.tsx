import { useState } from "react";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import { Layout } from "@/components/Layout";
import {
  useGetOrder,
  useUpdateOrderStatus,
  getGetOrderQueryKey,
  type OrderStatus,
} from "@workspace/api-client-react";
import { useParams, Link } from "wouter";
import { ArrowLeft, Phone, Calendar, X, Package, Share2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";

function imgSrc(url: string): string {
  return url.replace(/^\/objects\//, "/api/public/img/");
}

const STATUS_STYLES: Record<string, string> = {
  pending: "bg-amber-100 text-amber-800",
  confirmed: "bg-blue-100 text-blue-800",
  fulfilled: "bg-green-100 text-green-800",
};

function ImageLightbox({ src, alt, onClose }: { src: string; alt: string; onClose: () => void }) {
  return (
    <div
      className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4"
      onClick={onClose}
    >
      <button
        onClick={onClose}
        className="absolute top-4 right-4 text-white bg-black/50 rounded-full p-2 hover:bg-black/70 transition-colors"
        aria-label="Close"
      >
        <X className="w-5 h-5" />
      </button>
      <img
        src={src}
        alt={alt}
        className="max-w-full max-h-full object-contain rounded-lg"
        onClick={(e) => e.stopPropagation()}
      />
    </div>
  );
}

function ProductImage({ url, name }: { url: string; name: string }) {
  const [error, setError] = useState(false);
  const [lightbox, setLightbox] = useState(false);
  const src = imgSrc(url);

  if (error) {
    return (
      <div className="w-14 h-14 rounded-lg border border-slate-200 bg-slate-50 flex items-center justify-center shrink-0">
        <Package className="w-6 h-6 text-slate-300" />
      </div>
    );
  }

  return (
    <>
      <img
        src={src}
        alt={name}
        className="w-14 h-14 rounded-lg object-cover shrink-0 border border-slate-200 cursor-pointer hover:opacity-90 active:opacity-75 transition-opacity"
        onError={() => setError(true)}
        onClick={() => setLightbox(true)}
        title="Tap to view full size"
      />
      {lightbox && (
        <ImageLightbox src={src} alt={name} onClose={() => setLightbox(false)} />
      )}
    </>
  );
}

export default function OrderDetail() {
  return (
    <ProtectedRoute>
      <Layout>
        <OrderDetailContent />
      </Layout>
    </ProtectedRoute>
  );
}

function OrderDetailContent() {
  const params = useParams();
  const orderId = params.id as string;
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: order, isLoading } = useGetOrder(orderId, {
    query: {
      enabled: !!orderId,
      queryKey: getGetOrderQueryKey(orderId),
    },
  });

  const updateStatus = useUpdateOrderStatus();

  const handleStatusChange = async (newStatus: string) => {
    try {
      await updateStatus.mutateAsync({
        orderId,
        data: { status: newStatus as OrderStatus },
      });
      queryClient.invalidateQueries({ queryKey: getGetOrderQueryKey(orderId) });
      toast({ title: "Order status updated" });
    } catch (err: any) {
      toast({
        title: "Error",
        description: err.message || "Failed to update status",
        variant: "destructive",
      });
    }
  };

  if (isLoading) {
    return (
      <div className="p-8 text-center text-slate-500">Loading order...</div>
    );
  }

  if (!order) {
    return (
      <div className="p-8 text-center text-slate-500">Order not found</div>
    );
  }

  return (
    <div className="space-y-6 max-w-4xl">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:gap-4">
        <div className="flex items-center gap-3 min-w-0">
          <Link
            href="/orders"
            className="p-2 rounded-md hover:bg-slate-100 text-slate-500 transition-colors shrink-0"
          >
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900 truncate">
            Order {order.id}
          </h1>
        </div>
        <div className="flex items-center gap-3 sm:ml-auto shrink-0">
          <span
            className={`px-3 py-1 rounded-full text-sm font-medium capitalize ${STATUS_STYLES[order.status] ?? "bg-slate-100 text-slate-700"}`}
          >
            {order.status}
          </span>
          <Select
            value={order.status}
            onValueChange={handleStatusChange}
            disabled={updateStatus.isPending}
          >
            <SelectTrigger className="w-36 h-8 text-sm">
              <SelectValue placeholder="Update status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="confirmed">Confirmed</SelectItem>
              <SelectItem value="fulfilled">Fulfilled</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Items</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="divide-y divide-slate-100">
                {order.items.map((item, idx) => (
                  <div
                    key={idx}
                    className="py-4 first:pt-0 last:pb-0 flex gap-3 items-start"
                  >
                    {item.productImageSnapshot && (
                      <ProductImage
                        url={item.productImageSnapshot}
                        name={item.productNameSnapshot}
                      />
                    )}
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-slate-900">
                        {item.productNameSnapshot}
                      </p>
                      <p className="text-sm text-slate-500">
                        {item.quantity} × ₹{item.priceSnapshot}
                        {item.variantSnapshot && ` · ${item.variantSnapshot}`}
                      </p>
                    </div>
                    <div className="font-bold text-slate-900 shrink-0">
                      ₹{(item.quantity * item.priceSnapshot).toFixed(2)}
                    </div>
                  </div>
                ))}
                {(order as any).subtotalAmount != null && ((order as any).gstAmount > 0 || (order as any).shippingAmount > 0) ? (
                  <div className="pt-4 border-t border-slate-100 space-y-2">
                    <div className="flex justify-between items-center text-sm text-slate-500">
                      <span>Items Subtotal</span>
                      <span>₹{Number((order as any).subtotalAmount).toFixed(2)}</span>
                    </div>
                    {(order as any).gstAmount != null && (order as any).gstAmount > 0 && (
                      <div className="flex justify-between items-center text-sm text-slate-500">
                        <span>GST ({(order as any).gstPercentage}%)</span>
                        <span>₹{Number((order as any).gstAmount).toFixed(2)}</span>
                      </div>
                    )}
                    {(order as any).shippingAmount != null && (order as any).shippingAmount > 0 && (
                      <div className="flex justify-between items-center text-sm text-slate-500">
                        <span>Shipping ({(order as any).shippingKg ?? 1} kg shipping)</span>
                        <span>₹{Number((order as any).shippingAmount).toFixed(2)}</span>
                      </div>
                    )}
                    <div className="pt-2 flex justify-between items-center text-lg font-bold text-slate-900 border-t border-slate-100">
                      <span>Total</span>
                      <span>₹{order.totalAmount}</span>
                    </div>
                  </div>
                ) : (
                  <div className="pt-4 flex justify-between items-center text-lg font-bold text-slate-900 border-t border-slate-100">
                    <span>Total</span>
                    <span>₹{order.totalAmount}</span>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Customer Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-3 text-slate-600">
                <Phone className="w-4 h-4" />
                <span>{order.customerContact || "Not provided"}</span>
              </div>
              <div className="flex items-center gap-3 text-slate-600">
                <Calendar className="w-4 h-4" />
                <span>
                  {new Date(order.createdAt).toLocaleDateString("en-IN", {
                    day: "numeric",
                    month: "short",
                    year: "numeric",
                    hour: "2-digit",
                    minute: "2-digit",
                  })}
                </span>
              </div>
              <div className="pt-2 border-t border-slate-100">
                <Button
                  onClick={() => {
                    const url = `${window.location.origin}/store/orders/${order.id}`;
                    navigator.clipboard.writeText(url);
                    toast({
                      title: "Link Copied!",
                      description: "Public order link has been copied to clipboard.",
                    });
                  }}
                  className="w-full text-xs h-9 gap-1.5"
                  variant="outline"
                >
                  <Share2 className="w-3.5 h-3.5" />
                  Copy Order Link
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
