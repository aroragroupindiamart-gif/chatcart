import { Router, type IRouter, type Request, type Response } from "express";
import { Readable } from "stream";
import multer from "multer";
import { GetObjectCommand } from "@aws-sdk/client-s3";
import {
  RequestUploadUrlBody,
  RequestUploadUrlResponse,
  RequestLogoUploadUrlBody,
  RequestLogoUploadUrlResponse,
} from "@workspace/api-zod";
import { ObjectStorageService, ObjectNotFoundError, getS3Client, getS3BucketName } from "../lib/objectStorage";
import { requireAuth } from "../middleware/auth.js";
import { db } from "@workspace/db";
import { productImagesTable, productsTable } from "@workspace/db/schema";
import { eq, and, count } from "drizzle-orm";
import sharp from "sharp";

const ALLOWED_IMAGE_MIMES = new Set([
  "image/jpeg",
  "image/jpg",
  "image/png",
  "image/webp",
]);

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 25 * 1024 * 1024 }, // 25 MB hard limit
  fileFilter: (_req, file, cb) => {
    const mime = (file.mimetype || "").toLowerCase();
    if (ALLOWED_IMAGE_MIMES.has(mime)) {
      cb(null, true);
    } else {
      cb(new Error("Invalid file type. Only JPEG, PNG, and WebP images are allowed."));
    }
  },
});

function handleImageUpload(fieldName: string) {
  const single = upload.single(fieldName);
  return (req: Request, res: Response, next: any) => {
    single(req, res, (err: any) => {
      if (err) {
        if (err.message?.includes("Invalid file type")) {
          res.status(400).json({ error: err.message });
          return;
        }
        if (err.code === "LIMIT_FILE_SIZE") {
          res.status(400).json({ error: "File size exceeds 25 MB limit." });
          return;
        }
        res.status(400).json({ error: err.message || "Failed to parse upload" });
        return;
      }
      next();
    });
  };
}

const router: IRouter = Router();
const objectStorageService = new ObjectStorageService();

/**
 * POST /storage/uploads/file
 *
 * Proxy multipart product-image upload through the API server → DO Spaces.
 * Accepts a multipart/form-data body with fields:
 *   file        — the image file
 *   productId   — integer
 *   displayOrder — integer (0-indexed)
 *
 * Eliminates the need for browser ↔ DO Spaces CORS config.
 */
router.post(
  "/storage/uploads/file",
  requireAuth,
  handleImageUpload("file"),
  async (req: Request, res: Response) => {
    const file = req.file;
    if (!file) {
      res.status(400).json({ error: "No file provided" });
      return;
    }

    const productId = parseInt(req.body?.productId, 10);
    const displayOrder = parseInt(req.body?.displayOrder ?? "0", 10);

    if (!productId || isNaN(productId)) {
      res.status(400).json({ error: "Missing or invalid productId" });
      return;
    }

    const sellerId = req.seller!.sellerId;

    try {
      const [product] = await db
        .select({ id: productsTable.id })
        .from(productsTable)
        .where(and(eq(productsTable.id, productId), eq(productsTable.sellerId, sellerId)))
        .limit(1);

      if (!product) {
        res.status(404).json({ error: "Product not found or not owned by this seller" });
        return;
      }

      let uploadBuffer = file.buffer;
      let uploadMime = file.mimetype;

      try {
        if (file.mimetype.startsWith("image/")) {
          const image = sharp(file.buffer).rotate();
          const metadata = await image.metadata();
          if ((metadata.width && metadata.width > 2048) || (metadata.height && metadata.height > 2048) || file.size > 2 * 1024 * 1024) {
            uploadBuffer = await image
              .resize({ width: 2048, height: 2048, fit: "inside", withoutEnlargement: true })
              .jpeg({ quality: 88, progressive: true })
              .toBuffer();
            uploadMime = "image/jpeg";
          }
        }
      } catch (sharpErr) {
        req.log.warn({ err: sharpErr }, "Sharp optimization fallback to raw buffer");
      }

      const objectPath = await objectStorageService.uploadFileBuffer(uploadBuffer, uploadMime);

      const [newImage] = await db
        .insert(productImagesTable)
        .values({ productId, url: objectPath, displayOrder })
        .returning({ id: productImagesTable.id });

      res.json({ imageId: newImage.id, objectPath });
    } catch (error) {
      req.log.error({ err: error }, "Error uploading product image");
      res.status(500).json({ error: "Upload failed" });
    }
  }
);

/**
 * POST /storage/uploads/logo
 *
 * Proxy multipart logo/banner upload through the API server → DO Spaces.
 * Accepts a multipart/form-data body with a single `file` field.
 * Returns { objectPath } — caller saves this to the seller record.
 */
router.post(
  "/storage/uploads/logo",
  requireAuth,
  handleImageUpload("file"),
  async (req: Request, res: Response) => {
    const file = req.file;
    if (!file) {
      res.status(400).json({ error: "No file provided" });
      return;
    }

    try {
      let uploadBuffer = file.buffer;
      let uploadMime = file.mimetype;

      try {
        if (file.mimetype.startsWith("image/")) {
          const image = sharp(file.buffer).rotate();
          const metadata = await image.metadata();
          if ((metadata.width && metadata.width > 2048) || (metadata.height && metadata.height > 2048) || file.size > 2 * 1024 * 1024) {
            uploadBuffer = await image
              .resize({ width: 2048, height: 2048, fit: "inside", withoutEnlargement: true })
              .jpeg({ quality: 88, progressive: true })
              .toBuffer();
            uploadMime = "image/jpeg";
          }
        }
      } catch (sharpErr) {
        req.log.warn({ err: sharpErr }, "Sharp logo optimization fallback to raw buffer");
      }

      const objectPath = await objectStorageService.uploadFileBuffer(uploadBuffer, uploadMime);
      res.json({ objectPath });
    } catch (error) {
      req.log.error({ err: error }, "Error uploading logo");
      res.status(500).json({ error: "Upload failed" });
    }
  }
);

/**
 * POST /storage/uploads/request-url
 *
 * Request a presigned URL for a product image upload.
 * Requires productId — verifies the product belongs to the authenticated seller,
 * then atomically creates the product_images row and returns the presigned URL.
 */
router.post("/storage/uploads/request-url", requireAuth, async (req: Request, res: Response) => {
  const parsed = RequestUploadUrlBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Missing or invalid required fields" });
    return;
  }

  const { productId, name, size, contentType, displayOrder } = parsed.data;
  if (!ALLOWED_IMAGE_MIMES.has((contentType || "").toLowerCase())) {
    res.status(400).json({ error: "Invalid contentType. Only JPEG, PNG, and WebP images are allowed." });
    return;
  }
  const sellerId = req.seller!.sellerId;

  try {
    // Verify the product exists and belongs to the authenticated seller
    const [product] = await db
      .select({ id: productsTable.id })
      .from(productsTable)
      .where(and(eq(productsTable.id, productId), eq(productsTable.sellerId, sellerId)))
      .limit(1);

    if (!product) {
      res.status(404).json({ error: "Product not found or not owned by this seller" });
      return;
    }

    // Determine display order: if not provided, append after existing images
    let resolvedDisplayOrder = displayOrder;
    if (resolvedDisplayOrder === 0) {
      const [{ imageCount }] = await db
        .select({ imageCount: count() })
        .from(productImagesTable)
        .where(eq(productImagesTable.productId, productId));
      resolvedDisplayOrder = imageCount;
    }

    // Generate the presigned upload URL
    const uploadURL = await objectStorageService.getObjectEntityUploadURL();
    const objectPath = objectStorageService.normalizeObjectEntityPath(uploadURL);

    // Atomically create the product_images row before the upload happens.
    // The row is written now so the file is always linked to a product — no orphans.
    const [newImage] = await db
      .insert(productImagesTable)
      .values({
        productId,
        url: objectPath,
        displayOrder: resolvedDisplayOrder,
      })
      .returning({ id: productImagesTable.id });

    res.json(
      RequestUploadUrlResponse.parse({
        uploadURL,
        objectPath,
        imageId: newImage.id,
        metadata: { name, size, contentType },
      }),
    );
  } catch (error) {
    req.log.error({ err: error }, "Error generating upload URL");
    res.status(500).json({ error: "Failed to generate upload URL" });
  }
});

/**
 * POST /storage/uploads/request-logo-url
 *
 * Request a presigned URL for a seller logo or banner image upload.
 * These are not product images and are not linked to product_images rows —
 * they are referenced directly on the seller record (bannerImageUrl).
 */
router.post("/storage/uploads/request-logo-url", requireAuth, async (req: Request, res: Response) => {
  const parsed = RequestLogoUploadUrlBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Missing or invalid required fields" });
    return;
  }

  const { name, size, contentType } = parsed.data;
  if (!ALLOWED_IMAGE_MIMES.has((contentType || "").toLowerCase())) {
    res.status(400).json({ error: "Invalid contentType. Only JPEG, PNG, and WebP images are allowed." });
    return;
  }

  try {
    const uploadURL = await objectStorageService.getObjectEntityUploadURL();
    const objectPath = objectStorageService.normalizeObjectEntityPath(uploadURL);

    res.json(
      RequestLogoUploadUrlResponse.parse({
        uploadURL,
        objectPath,
        metadata: { name, size, contentType },
      }),
    );
  } catch (error) {
    req.log.error({ err: error }, "Error generating logo upload URL");
    res.status(500).json({ error: "Failed to generate upload URL" });
  }
});

/**
 * GET /storage/public-objects/*
 *
 * Serve public assets from PUBLIC_OBJECT_SEARCH_PATHS.
 * These are unconditionally public — no authentication or ACL checks.
 * IMPORTANT: Always provide this endpoint when object storage is set up.
 */
router.get("/storage/public-objects/*filePath", async (req: Request, res: Response) => {
  try {
    const raw = req.params.filePath;
    const filePath = Array.isArray(raw) ? raw.join("/") : raw;
    const cleanPath = (filePath || "").replace(/^\/+/, "");

    // Security check: restrict public objects to public/ or uploads/ and disallow path traversal / backups
    if (cleanPath.includes("..") || cleanPath.includes("\0") || cleanPath.startsWith("backups/") || (!cleanPath.startsWith("public/") && !cleanPath.startsWith("uploads/"))) {
      res.status(404).json({ error: "File not found" });
      return;
    }

    const file = await objectStorageService.searchPublicObject(cleanPath);
    if (!file) {
      res.status(404).json({ error: "File not found" });
      return;
    }

    const response = await objectStorageService.downloadObject(file);

    res.status(response.status);
    response.headers.forEach((value, key) => res.setHeader(key, value));

    if (response.body) {
      const nodeStream = Readable.fromWeb(response.body as ReadableStream<Uint8Array>);
      nodeStream.pipe(res);
    } else {
      res.end();
    }
  } catch (error) {
    req.log.error({ err: error }, "Error serving public object");
    res.status(500).json({ error: "Failed to serve public object" });
  }
});

/**
 * GET /storage/objects/uploads/:filename
 *
 * Serve uploaded object entities (product images) for the authenticated seller.
 * Restricted to the uploads/ prefix only — no path traversal, no cross-prefix access.
 * Images are also accessible publicly via /api/public/img/uploads/:filename.
 */
router.get("/storage/objects/uploads/:filename", requireAuth, async (req: Request, res: Response) => {
  try {
    const { filename } = req.params;
    // Reject path traversal attempts
    if (!filename || filename.includes("/") || filename.includes("..") || filename.includes("\0")) {
      res.status(400).json({ error: "Invalid filename" });
      return;
    }
    const objectPath = `/objects/uploads/${filename}`;

    // Ownership check: ensure the file belongs to a product owned by the authenticated seller.
    // Return 403 without revealing whether the file exists.
    const sellerId = req.seller!.sellerId;
    const ownershipRows = await db
      .select({ id: productImagesTable.id })
      .from(productImagesTable)
      .innerJoin(productsTable, eq(productImagesTable.productId, productsTable.id))
      .where(
        and(
          eq(productImagesTable.url, objectPath),
          eq(productsTable.sellerId, sellerId),
        ),
      )
      .limit(1);

    if (ownershipRows.length === 0) {
      res.status(403).json({ error: "Forbidden" });
      return;
    }

    const objectFile = await objectStorageService.getObjectEntityFile(objectPath);

    const response = await objectStorageService.downloadObject(objectFile);

    res.status(response.status);
    response.headers.forEach((value, key) => res.setHeader(key, value));

    if (response.body) {
      const nodeStream = Readable.fromWeb(response.body as ReadableStream<Uint8Array>);
      nodeStream.pipe(res);
    } else {
      res.end();
    }
  } catch (error) {
    if (error instanceof ObjectNotFoundError) {
      req.log.warn({ err: error }, "Object not found");
      res.status(404).json({ error: "Object not found" });
      return;
    }
    req.log.error({ err: error }, "Error serving object");
    res.status(500).json({ error: "Failed to serve object" });
  }
});

/**
 * GET /public/img/*path
 *
 * Serve product images publicly (no auth required).
 * Product images are inherently public — they're shown on the customer storefront.
 * Path should be the objectPath without the leading /objects/ prefix,
 * e.g. /api/public/img/uploads/<uuid>
 */
router.get("/public/img/*path", async (req: Request, res: Response) => {
  try {
    const raw = req.params.path;
    const filePath = Array.isArray(raw) ? raw.join("/") : raw;
    const cleanPath = (filePath || "").replace(/^\/+/, "");

    // Security check: strictly restrict to uploaded assets (product images / logos)
    // Never allow traversing into backups/ or other prefixes in the bucket
    if (cleanPath.includes("..") || cleanPath.includes("\0") || !cleanPath.startsWith("uploads/")) {
      res.status(404).json({ error: "Image not found" });
      return;
    }

    const s3Key = cleanPath; // e.g. uploads/<uuid>

    const client = getS3Client();
    const bucket = getS3BucketName();

    // Directly fetch the object using GetObjectCommand in exactly 1 S3 API call
    const resp = await client.send(
      new GetObjectCommand({ Bucket: bucket, Key: s3Key })
    );

    res.setHeader("Content-Type", resp.ContentType || "image/jpeg");
    res.setHeader("Content-Security-Policy", "default-src 'none'; script-src 'none'; sandbox");
    res.setHeader("X-Content-Type-Options", "nosniff");
    
    // Explicitly allow public caching to let Nginx and browsers cache it aggressively
    res.setHeader("Cache-Control", "public, max-age=31536000, immutable");

    const width = req.query.w ? parseInt(req.query.w as string, 10) : null;

    const body = resp.Body as any;
    if (body) {
      const { Readable } = await import("stream");
      let stream: any;
      if (body instanceof Readable) {
        stream = body;
      } else if (body && typeof body[Symbol.asyncIterator] === "function") {
        stream = Readable.fromWeb(body);
      }

      if (stream && width && width > 0 && width < 1200) {
        const chunks: any[] = [];
        for await (const chunk of stream) {
          chunks.push(typeof chunk === "string" ? Buffer.from(chunk) : chunk);
        }
        const buffer = Buffer.concat(chunks);
        const resizedBuffer = await sharp(buffer)
          .resize(width, null, { fit: "inside", withoutEnlargement: true })
          .toBuffer();

        res.setHeader("Content-Length", String(resizedBuffer.length));
        res.end(resizedBuffer);
      } else if (stream) {
        if (resp.ContentLength !== undefined) {
          res.setHeader("Content-Length", String(resp.ContentLength));
        }
        stream.pipe(res);
      } else {
        res.end();
      }
    } else {
      res.end();
    }
  } catch (error: any) {
    if (error.name === "NoSuchKey" || error.name === "NotFound") {
      res.status(404).json({ error: "Image not found" });
      return;
    }
    req.log.error({ err: error }, "Error serving public image");
    res.status(500).json({ error: "Failed to serve image" });
  }
});

export default router;
