import { ProtectedRoute } from "@/components/ProtectedRoute";
import { Layout } from "@/components/Layout";
import {
  useGetProduct,
  useCreateProduct,
  useUpdateProduct,
  useListCategories,
  getGetProductQueryKey,
  ProductStatus,
  useDeleteProduct,
  useGetMe,
  useDeleteProductImage,
  useReorderProductImages,
  listProducts,
} from "@workspace/api-client-react";

async function uploadImageToApi(
  file: File,
  productId: number,
  displayOrder: number
): Promise<{ imageId: number; objectPath: string }> {
  const formData = new FormData();
  formData.append("file", file);
  formData.append("productId", String(productId));
  formData.append("displayOrder", String(displayOrder));

  const token = localStorage.getItem("chatcart_token");
  const res = await fetch("/api/storage/uploads/file", {
    method: "POST",
    body: formData,
    headers: token ? { Authorization: `Bearer ${token}` } : {},
  });

  if (!res.ok) {
    const data = await res.json().catch(() => ({}));
    throw new Error(data.error || `Upload failed (${res.status})`);
  }
  return res.json();
}
import { useLocation, useParams } from "wouter";
import { useEffect, useRef, useState, useCallback, useMemo } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, Save, Trash, Share2, Upload, X, Image as ImageIcon, Loader2, AlertCircle, RefreshCw, GripVertical, Link2, Check } from "lucide-react";
import { Link } from "wouter";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Checkbox } from "@/components/ui/checkbox";
import { useQueryClient } from "@tanstack/react-query";
import {
  DndContext,
  closestCenter,
  PointerSensor,
  TouchSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from "@dnd-kit/core";
import {
  SortableContext,
  rectSortingStrategy,
  useSortable,
  arrayMove,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";

import { optimizeImageForUpload } from "@/lib/imageOptimizer";

const ALLOWED_TYPES = ["image/jpeg", "image/png", "image/webp"];
const MAX_RAW_INPUT_BYTES = 25 * 1024 * 1024; // Allow selecting up to 25MB phone camera photos

/** Key used to pass failed-upload metadata from the create flow to the edit page via sessionStorage. */
const retryStorageKey = (productId: number) => `chatcart_pendingRetry_${productId}`;

function imgSrc(url: string): string {
  if (url.startsWith("/objects/")) {
    return `/api/public/img/${url.slice("/objects/".length)}`;
  }
  return url;
}

function normalizeWhatsAppNumber(raw: string): string {
  const digits = raw.replace(/\D/g, "");
  if (digits.length === 10) return `91${digits}`;
  if (digits.startsWith("91") && digits.length === 12) return digits;
  if (digits.startsWith("0") && digits.length === 11) return `91${digits.slice(1)}`;
  return digits;
}

export default function ProductDetail() {
  const params = useParams();
  const routeKey = params.id ?? "new";
  return (
    <ProtectedRoute>
      <Layout>
        <ProductDetailContent key={routeKey} />
      </Layout>
    </ProtectedRoute>
  );
}

interface UploadingFile {
  id: string;
  file: File;
  name: string;
  preview: string;
  status: "uploading" | "done" | "error";
  error?: string;
}

interface PendingFile {
  id: string;
  file: File;
  preview: string;
  status: "pending" | "uploading" | "done" | "error";
  error?: string;
}

interface UploadResult {
  id: string;
  name: string;
  status: "done" | "error";
  error?: string;
}

/** Items persisted in sessionStorage to show retry UI on the edit page. */
interface RetryItem {
  name: string;
  error?: string;
}

interface OrderedImage {
  id: number;
  url: string;
  displayOrder: number;
}

import { Maximize2 } from "lucide-react";

function ImageLightbox({ src, alt, onClose }: { src: string; alt: string; onClose: () => void }) {
  return (
    <div
      className="fixed inset-0 z-50 bg-black/90 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-200"
      onClick={onClose}
    >
      <button
        type="button"
        onClick={onClose}
        className="absolute top-4 right-4 text-white bg-black/60 hover:bg-black/90 rounded-full p-2.5 transition-colors shadow-lg z-50 cursor-pointer"
        aria-label="Close picture"
      >
        <X className="w-6 h-6" />
      </button>
      <div className="relative max-w-4xl max-h-[90vh] flex items-center justify-center">
        <img
          src={src}
          alt={alt}
          className="max-w-full max-h-[85vh] object-contain rounded-xl shadow-2xl"
          onClick={(e) => e.stopPropagation()}
        />
      </div>
    </div>
  );
}

// ── Sortable image thumbnail ──────────────────────────────────────────────────

interface SortableImageProps {
  img: OrderedImage;
  isPrimary: boolean;
  onDelete: (id: number) => void;
  onView: (url: string) => void;
}

function SortableImage({ img, isPrimary, onDelete, onView }: SortableImageProps) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: img.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
    zIndex: isDragging ? 10 : undefined,
  };

  const fullUrl = imgSrc(img.url);

  return (
    <div
      ref={setNodeRef}
      style={style}
      className="relative group aspect-square rounded-lg overflow-hidden border border-slate-200 bg-slate-50 touch-none cursor-pointer"
      onClick={() => onView(fullUrl)}
    >
      <img
        src={fullUrl}
        alt="Product"
        className="w-full h-full object-cover"
        draggable={false}
      />

      {/* View full size zoom button */}
      <button
        type="button"
        onClick={(e) => {
          e.stopPropagation();
          onView(fullUrl);
        }}
        className="absolute top-1 left-1 bg-black/60 hover:bg-black/80 text-white rounded-full p-1.5 transition-opacity shadow z-10 opacity-90 group-hover:opacity-100"
        title="View full size picture"
      >
        <Maximize2 className="w-3.5 h-3.5" />
      </button>

      {/* Primary badge */}
      {isPrimary && (
        <div className="absolute bottom-1 left-1 bg-indigo-600 text-white text-[10px] font-semibold px-1.5 py-0.5 rounded-full leading-none pointer-events-none z-10 shadow">
          Primary
        </div>
      )}

      {/* Delete button */}
      <button
        type="button"
        onClick={(e) => {
          e.stopPropagation();
          onDelete(img.id);
        }}
        className="absolute top-1 right-1 bg-red-500 hover:bg-red-600 text-white rounded-full p-1 opacity-80 group-hover:opacity-100 transition-opacity shadow z-10"
        title="Delete photo"
      >
        <X className="w-3.5 h-3.5" />
      </button>

      {/* Drag indicator */}
      <div
        {...attributes}
        {...listeners}
        onClick={(e) => e.stopPropagation()}
        className="absolute bottom-1 right-1 opacity-70 group-hover:opacity-100 transition-opacity z-10 cursor-grab active:cursor-grabbing p-1 bg-black/50 hover:bg-black/70 rounded text-white"
        title="Drag to reorder"
      >
        <GripVertical className="w-3.5 h-3.5" />
      </div>
    </div>
  );
}

// ── Uploading file thumbnail (in-progress or error) ───────────────────────────

interface UploadingThumbProps {
  entry: UploadingFile;
  onRetry: (entry: UploadingFile) => void;
  onDismiss: (id: string) => void;
}

function UploadingThumb({ entry, onRetry, onDismiss }: UploadingThumbProps) {
  return (
    <div className="relative aspect-square rounded-lg overflow-hidden border border-slate-200 bg-slate-50">
      <img src={entry.preview} alt={entry.name} className="w-full h-full object-cover opacity-40" />

      {entry.status === "uploading" && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/20">
          <Loader2 className="w-6 h-6 text-white animate-spin drop-shadow" />
          <span className="text-[10px] text-white mt-1 font-medium drop-shadow">Uploading…</span>
        </div>
      )}

      {entry.status === "error" && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-red-900/50 gap-1 p-1">
          <AlertCircle className="w-5 h-5 text-red-200" />
          <p className="text-[9px] text-red-100 text-center leading-tight line-clamp-2">{entry.error ?? "Upload failed"}</p>
          <button
            onClick={() => onRetry(entry)}
            className="mt-0.5 flex items-center gap-0.5 bg-white/90 text-red-700 text-[9px] font-semibold px-1.5 py-0.5 rounded-full hover:bg-white transition-colors"
          >
            <RefreshCw className="w-2.5 h-2.5" />
            Retry
          </button>
          <button
            onClick={() => onDismiss(entry.id)}
            className="absolute top-0.5 right-0.5 text-white/70 hover:text-white"
          >
            <X className="w-3 h-3" />
          </button>
        </div>
      )}
    </div>
  );
}

// ── Main component ────────────────────────────────────────────────────────────

function ProductDetailContent() {
  const params = useParams();
  const isNew = !params.id || params.id === "new";
  const productId = isNew ? 0 : parseInt(params.id as string, 10);
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: product, isLoading } = useGetProduct(productId, {
    query: {
      enabled: !isNew && !!productId,
      queryKey: getGetProductQueryKey(productId),
    },
  });

  const { data: meData } = useGetMe();
  const { data: categories } = useListCategories();

  const plan = meData?.subscriptionPlan ?? "starter";
  const hasVariantsAccess = plan === "growth" || plan === "pro" || plan === "lifetime";

  const createProduct = useCreateProduct();
  const updateProduct = useUpdateProduct();
  const deleteProduct = useDeleteProduct();
  const deleteProductImage = useDeleteProductImage();
  const reorderProductImages = useReorderProductImages();

  const fileInputRef = useRef<HTMLInputElement>(null);

  // In-flight / failed uploads for saved products
  const [uploadingFiles, setUploadingFiles] = useState<UploadingFile[]>([]);

  // Queue of photos selected on the "new product" form before the product is saved
  const [pendingFiles, setPendingFiles] = useState<PendingFile[]>([]);

  // Whether a post-create upload batch is in progress
  const [isUploadingAfterCreate, setIsUploadingAfterCreate] = useState(false);

  // Items loaded from sessionStorage — failed uploads from a previous create attempt
  const [retryItems, setRetryItems] = useState<RetryItem[]>([]);

  // Local ordered image list — drives the drag-to-reorder UI
  const [orderedImages, setOrderedImages] = useState<OrderedImage[]>([]);
  const orderedImagesRef = useRef<OrderedImage[]>([]);
  orderedImagesRef.current = orderedImages;

  const [name, setName] = useState("");
  const [sku, setSku] = useState("");
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState("");
  const [stockCount, setStockCount] = useState("");
  const [categoryId, setCategoryId] = useState<string>("");
  const [categoryIds, setCategoryIds] = useState<number[]>([]);
  const [status, setStatus] = useState<string>("active");
  const [showWhenOutOfStock, setShowWhenOutOfStock] = useState(false);
  const [variants, setVariants] = useState<Array<{ id?: number; variantType: string; options: string[] }>>([]);

  useEffect(() => {
    if (product && !isNew) {
      setName(product.name);
      setSku(product.sku || "");
      setDescription(product.description || "");
      setPrice(product.price != null ? product.price.toString() : "");
      setStockCount(product.stockCount.toString());
      setCategoryId(product.categoryId?.toString() || "");
      setCategoryIds((product as any).categoryIds || (product.categoryId ? [product.categoryId] : []));
      setStatus(product.status);
      setShowWhenOutOfStock(product.showWhenOutOfStock);
      setVariants(
        (product.variants || []).map((v: any) => ({
          id: v.id,
          variantType: v.label || v.variantType,
          options: v.options || [],
        }))
      );
    }
  }, [product, isNew]);

  // Full-size image preview lightbox modal
  const [previewImageUrl, setPreviewImageUrl] = useState<string | null>(null);

  const [deletedImageIds, setDeletedImageIds] = useState<number[]>([]);

  // Sync orderedImages from product data, but preserve local order during active drag sessions and filter out deleted
  const [isDragging, setIsDragging] = useState(false);
  useEffect(() => {
    if (product?.images && !isDragging) {
      setOrderedImages(
        [...product.images]
          .filter((img) => !deletedImageIds.includes(img.id))
          .sort((a, b) => a.displayOrder - b.displayOrder)
      );
    }
  }, [product?.images, isDragging, deletedImageIds]);

  const hasUnsavedChanges = useMemo(() => {
    const hasUnsavedPhotos = pendingFiles.some((f) => f.status !== "done");
    if (isNew) {
      return Boolean(name.trim() || price || description.trim() || hasUnsavedPhotos);
    }
    if (!product) return false;
    if (deletedImageIds.length > 0) return true;
    if (hasUnsavedPhotos) return true;
    if (name !== product.name) return true;
    if (sku !== (product.sku || "")) return true;
    if (description !== (product.description || "")) return true;
    const origPrice = product.price != null ? product.price.toString() : "";
    if (price !== origPrice) return true;
    if (stockCount !== product.stockCount.toString()) return true;
    const origCatId = product.categoryId?.toString() || "";
    if (categoryId !== origCatId) return true;
    if (status !== product.status) return true;
    if (showWhenOutOfStock !== product.showWhenOutOfStock) return true;
    return false;
  }, [
    isNew,
    product,
    deletedImageIds,
    pendingFiles,
    name,
    sku,
    description,
    price,
    stockCount,
    categoryId,
    status,
    showWhenOutOfStock,
  ]);

  const navigateBack = () => {
    let returnUrl = new URLSearchParams(window.location.search).get("returnUrl") || "/products";
    if (returnUrl.startsWith("/app/")) {
      returnUrl = returnUrl.slice(4);
    } else if (returnUrl === "/app") {
      returnUrl = "/products";
    }
    if (!returnUrl.startsWith("/")) {
      returnUrl = `/${returnUrl}`;
    }
    setLocation(returnUrl);
  };

  const handleBackClick = (e: React.MouseEvent) => {
    e.preventDefault();
    if (hasUnsavedChanges) {
      const leave = window.confirm("You have unsaved changes. Do you want to discard them and leave?");
      if (!leave) return;
    }
    navigateBack();
  };

  const handleDiscard = () => {
    if (hasUnsavedChanges) {
      const confirmed = window.confirm("Discard all unsaved changes and restore original details and photos?");
      if (!confirmed) return;
    }

    if (!isNew && product) {
      setName(product.name);
      setSku(product.sku || "");
      setDescription(product.description || "");
      setPrice(product.price != null ? product.price.toString() : "");
      setStockCount(product.stockCount.toString());
      setCategoryId(product.categoryId?.toString() || "");
      setCategoryIds((product as any).categoryIds || (product.categoryId ? [product.categoryId] : []));
      setStatus(product.status);
      setShowWhenOutOfStock(product.showWhenOutOfStock);
      setVariants(
        (product.variants || []).map((v: any) => ({
          id: v.id,
          variantType: v.label || v.variantType,
          options: v.options || [],
        }))
      );
      setDeletedImageIds([]);
      setOrderedImages([...product.images].sort((a, b) => a.displayOrder - b.displayOrder));
      pendingFiles.forEach((f) => URL.revokeObjectURL(f.preview));
      setPendingFiles([]);
      toast({ title: "Changes discarded", description: "Original photos and product details restored." });
    } else {
      pendingFiles.forEach((f) => URL.revokeObjectURL(f.preview));
      setPendingFiles([]);
      navigateBack();
    }
  };

  const [copiedLink, setCopiedLink] = useState(false);
  const handleCopyLink = () => {
    const storeSubdomain = meData?.subdomain || "";
    const productUrl = storeSubdomain
      ? `https://chatcart.in/store/${storeSubdomain}/p/${productId}`
      : `https://chatcart.in/p/${productId}`;
    navigator.clipboard
      .writeText(productUrl)
      .then(() => {
        setCopiedLink(true);
        setTimeout(() => setCopiedLink(false), 2000);
        toast({ title: "Product link copied to clipboard!" });
      })
      .catch(() => {
        toast({ title: "Failed to copy link" });
      });
  };

  // On the edit page, check sessionStorage for failed uploads from the create flow
  useEffect(() => {
    if (!isNew && productId) {
      const key = retryStorageKey(productId);
      const raw = sessionStorage.getItem(key);
      if (raw) {
        try {
          setRetryItems(JSON.parse(raw) as RetryItem[]);
        } catch {
          // ignore malformed data
        }
        sessionStorage.removeItem(key);
      }
    }
  }, [isNew, productId]);

  // dnd-kit sensors — pointer for mouse, touch for mobile
  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 5 } }),
    useSensor(TouchSensor, { activationConstraint: { delay: 150, tolerance: 5 } })
  );

  const handleDragEnd = useCallback(
    (event: DragEndEvent) => {
      setIsDragging(false);
      const { active, over } = event;
      if (!over || active.id === over.id) return;

      // Compute the new order synchronously using the current ref value
      const current = orderedImagesRef.current;
      const oldIndex = current.findIndex((img) => img.id === active.id);
      const newIndex = current.findIndex((img) => img.id === over.id);
      const next = arrayMove(current, oldIndex, newIndex);

      setOrderedImages(next);

      reorderProductImages.mutate(
        {
          productId,
          data: {
            items: next.map((img, index) => ({
              id: img.id,
              displayOrder: index,
            })),
          },
        },
        {
          onError: () => {
            toast({ title: "Failed to save image order", variant: "destructive" });
          },
          onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: getGetProductQueryKey(productId) });
          },
        }
      );
    },
    [productId, reorderProductImages, queryClient, toast]
  );

  /**
   * Upload a single file to an already-created product.
   */
  const uploadSingleFile = async (
    file: File,
    entryId: string,
    targetProductId: number,
    displayOrder: number
  ): Promise<UploadResult> => {
    try {
      await uploadImageToApi(file, targetProductId, displayOrder);

      setUploadingFiles((prev) =>
        prev.map((e) => (e.id === entryId ? { ...e, status: "done" } : e))
      );
      return { id: entryId, name: file.name, status: "done" };
    } catch (err: any) {
      setUploadingFiles((prev) =>
        prev.map((e) =>
          e.id === entryId ? { ...e, status: "error", error: err.message } : e
        )
      );
      return { id: entryId, name: file.name, status: "error", error: err.message };
    }
  };

  /**
   * Upload a batch of pending files to an already-created product.
   */
  const uploadFilesToProduct = async (
    files: PendingFile[],
    targetProductId: number,
    existingImageCount: number
  ): Promise<UploadResult[]> => {
    const results: UploadResult[] = [];

    for (let i = 0; i < files.length; i++) {
      const entry = files[i];
      setPendingFiles((prev) =>
        prev.map((f) => (f.id === entry.id ? { ...f, status: "uploading" } : f))
      );

      try {
        await uploadImageToApi(entry.file, targetProductId, existingImageCount + i);

        setPendingFiles((prev) =>
          prev.map((f) => (f.id === entry.id ? { ...f, status: "done" } : f))
        );
        results.push({ id: entry.id, name: entry.file.name, status: "done" });
      } catch (err: any) {
        setPendingFiles((prev) =>
          prev.map((f) =>
            f.id === entry.id ? { ...f, status: "error", error: err.message } : f
          )
        );
        results.push({ id: entry.id, name: entry.file.name, status: "error", error: err.message });
      }
    }

    return results;
  };

  const handleSave = async () => {
    if (!name.trim()) {
      toast({ title: "Validation Error", description: "Product name is required", variant: "destructive" });
      return;
    }

    const resolvedCategoryId =
      categoryId && categoryId !== "unassigned" ? Number(categoryId) : null;
    const resolvedPrice = price.trim() !== "" ? Number(price) : undefined;
    const resolvedSku = sku.trim() || undefined;

    // Soft SKU uniqueness check
    if (resolvedSku) {
      try {
        const existing = await listProducts({ search: resolvedSku });
        const duplicate = existing?.find(
          (p) => p.sku?.toLowerCase() === resolvedSku.toLowerCase() && p.id !== productId
        );
        if (duplicate) {
          const proceed = window.confirm(
            `This SKU is already used by "${duplicate.name}" — save anyway?`
          );
          if (!proceed) return;
        }
      } catch {
        // Non-blocking — proceed if the check fails
      }
    }

    try {
      if (isNew) {
        const newProduct = await createProduct.mutateAsync({
          data: {
            name,
            sku: resolvedSku,
            description: description || undefined,
            price: resolvedPrice ?? 0,
            stockCount: Number(stockCount) || 0,
            categoryId: resolvedCategoryId ?? undefined,
            categoryIds: categoryIds,
          } as any,
        });

        const newId = newProduct.id;

        // Save product variants
        if (variants.length > 0) {
          for (const v of variants) {
            if (v.options.length > 0 && v.variantType.trim()) {
              await fetch(`/api/products/${newId}/variants`, {
                method: "POST",
                headers: {
                  "Content-Type": "application/json",
                  "Authorization": `Bearer ${localStorage.getItem("chatcart_token")}`,
                },
                body: JSON.stringify({ variantType: v.variantType, options: v.options }),
              });
            }
          }
        }

        if (pendingFiles.length > 0) {
          setIsUploadingAfterCreate(true);
          const snapshot = [...pendingFiles];
          const results = await uploadFilesToProduct(snapshot, newId, 0);
          setIsUploadingAfterCreate(false);

          snapshot.forEach((f) => URL.revokeObjectURL(f.preview));
          setPendingFiles([]);

          const failed = results.filter((r) => r.status === "error");
          if (failed.length > 0) {
            sessionStorage.setItem(
              retryStorageKey(newId),
              JSON.stringify(failed.map((r) => ({ name: r.name, error: r.error })))
            );
            toast({
              title: `${failed.length} photo${failed.length > 1 ? "s" : ""} failed to upload`,
              description: "You can re-add them from the product page.",
              variant: "destructive",
            });
          } else {
            toast({ title: "Product created successfully" });
          }
        } else {
          toast({ title: "Product created successfully" });
        }

        let returnUrl = new URLSearchParams(window.location.search).get("returnUrl") || "/products";
        if (returnUrl.startsWith("/app/")) {
          returnUrl = returnUrl.slice(4);
        } else if (returnUrl === "/app") {
          returnUrl = "/products";
        }
        if (!returnUrl.startsWith("/")) {
          returnUrl = `/${returnUrl}`;
        }
        setLocation(`/products/${newId}?returnUrl=${encodeURIComponent(returnUrl)}`);
      } else {
        // 1. Permanently delete images that were staged for deletion
        if (deletedImageIds.length > 0) {
          for (const imgId of deletedImageIds) {
            try {
              await deleteProductImage.mutateAsync({ productId, imageId: imgId });
            } catch (err) {
              console.error("Failed to delete staged image:", imgId, err);
            }
          }
          setDeletedImageIds([]);
        }

        // 2. Upload any new photos staged in pendingFiles
        if (pendingFiles.length > 0) {
          const snapshot = [...pendingFiles];
          await uploadFilesToProduct(snapshot, productId, orderedImages.length);
          snapshot.forEach((f) => URL.revokeObjectURL(f.preview));
          setPendingFiles([]);
        }

        // 3. Update product details
        await updateProduct.mutateAsync({
          productId,
          data: {
            name,
            sku: resolvedSku ?? "",
            description,
            price: resolvedPrice,
            stockCount: Number(stockCount) || 0,
            categoryId: resolvedCategoryId ?? undefined,
            categoryIds: categoryIds,
            status: status as ProductStatus,
            showWhenOutOfStock,
          } as any,
        });

        // 4. Sync product variants (delete old, insert new)
        if (product?.variants && product.variants.length > 0) {
          for (const orig of product.variants) {
            await fetch(`/api/products/${productId}/variants/${orig.id}`, {
              method: "DELETE",
              headers: {
                "Authorization": `Bearer ${localStorage.getItem("chatcart_token")}`,
              },
            });
          }
        }

        for (const v of variants) {
          if (v.options.length > 0 && v.variantType.trim()) {
            await fetch(`/api/products/${productId}/variants`, {
              method: "POST",
              headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${localStorage.getItem("chatcart_token")}`,
              },
              body: JSON.stringify({ variantType: v.variantType, options: v.options }),
            });
          }
        }

        queryClient.invalidateQueries({ queryKey: getGetProductQueryKey(productId) });
        queryClient.invalidateQueries({ queryKey: ["/api/products"] });
        toast({ title: "Product updated successfully" });
        navigateBack();
      }
    } catch (err: any) {
      toast({ title: "Error", description: err.message || "Failed to save product", variant: "destructive" });
    }
  };

  const handleDelete = async () => {
    if (!confirm("Are you sure you want to delete this product?")) return;
    try {
      await deleteProduct.mutateAsync({ productId });
      toast({ title: "Product deleted" });
      navigateBack();
    } catch (err: any) {
      toast({ title: "Error", description: err.message || "Failed to delete product", variant: "destructive" });
    }
  };

  const handleShare = () => {
    const wa = meData?.whatsappNumber ?? "";
    const phone = normalizeWhatsAppNumber(wa);
    const productUrl = meData?.subdomain
      ? `https://chatcart.in/store/${meData.subdomain}/p/${productId}`
      : `https://chatcart.in/p/${productId}`;
    const text = encodeURIComponent(`Check out ${name} for ₹${price}!\n${productUrl}`);
    if (!phone) {
      toast({
        title: "WhatsApp number not set",
        description: "Please set your WhatsApp number in Settings first.",
        variant: "destructive",
      });
      return;
    }
    window.open(`https://wa.me/${phone}?text=${text}`, "_blank");
  };

  const validateFiles = (files: FileList | null): File[] => {
    if (!files || files.length === 0) return [];
    const valid: File[] = [];
    for (const file of Array.from(files)) {
      if (!ALLOWED_TYPES.includes(file.type)) {
        toast({ title: `${file.name}: unsupported type`, description: "Only JPG, PNG, WebP allowed.", variant: "destructive" });
        continue;
      }
      if (file.size > MAX_RAW_INPUT_BYTES) {
        toast({ title: `${file.name}: too large`, description: "Max 25 MB per image.", variant: "destructive" });
        continue;
      }
      valid.push(file);
    }
    return valid;
  };

  const handleFilesSelected = async (files: FileList | null) => {
    const valid = validateFiles(files);
    if (valid.length === 0) return;

    // Automatically optimize high-resolution camera images without compromising visual quality
    const optimizedFiles = await Promise.all(
      valid.map(async (file) => {
        try {
          return await optimizeImageForUpload(file);
        } catch {
          return file;
        }
      })
    );

    const entries: PendingFile[] = optimizedFiles.map((f) => ({
      id: Math.random().toString(36).slice(2),
      file: f,
      preview: URL.createObjectURL(f),
      status: "pending" as const,
    }));
    setPendingFiles((prev) => [...prev, ...entries]);
  };

  const handleRetryUpload = async (entry: UploadingFile) => {
    setUploadingFiles((prev) =>
      prev.map((e) => (e.id === entry.id ? { ...e, status: "uploading", error: undefined } : e))
    );
    const existingCount = (product?.images?.length ?? 0);
    const result = await uploadSingleFile(entry.file, entry.id, productId, existingCount);
    if (result.status === "done") {
      setUploadingFiles((prev) => prev.filter((e) => e.id !== entry.id));
      queryClient.invalidateQueries({ queryKey: getGetProductQueryKey(productId) });
    }
  };

  const handleDismissUploadError = (id: string) => {
    setUploadingFiles((prev) => {
      const entry = prev.find((e) => e.id === id);
      if (entry) URL.revokeObjectURL(entry.preview);
      return prev.filter((e) => e.id !== id);
    });
  };

  const handleRemovePendingFile = (id: string) => {
    setPendingFiles((prev) => {
      const file = prev.find((f) => f.id === id);
      if (file) URL.revokeObjectURL(file.preview);
      return prev.filter((f) => f.id !== id);
    });
  };

  const handleDeleteImage = (imageId: number) => {
    setDeletedImageIds((prev) => [...prev, imageId]);
    setOrderedImages((prev) => prev.filter((img) => img.id !== imageId));
    toast({
      title: "Photo marked for removal",
      description: "Click 'Save Changes' to permanently delete or 'Discard Changes' to restore.",
    });
  };

  if (!isNew && isLoading) {
    return <div className="p-8 text-center text-slate-500">Loading product...</div>;
  }

  const isSaving = createProduct.isPending || updateProduct.isPending;
  const hasPendingFiles = pendingFiles.some((f) => f.status !== "done");
  const hasExistingOrUploading = orderedImages.length > 0 || uploadingFiles.length > 0 || hasPendingFiles;

  return (
    <div className="space-y-6 max-w-3xl">
      {/* ── Header ── */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={handleBackClick}
            className="p-2 rounded-md hover:bg-slate-100 text-slate-500 transition-colors cursor-pointer"
            aria-label="Back"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            {isNew ? "New Product" : "Edit Product"}
          </h1>
        </div>
        <div className="flex items-center flex-wrap gap-2 w-full sm:w-auto justify-end">
          {!isNew && (
            <>
              <Button variant="outline" size="sm" onClick={handleCopyLink} type="button">
                {copiedLink ? <Check className="w-4 h-4 mr-2 text-emerald-600" /> : <Link2 className="w-4 h-4 mr-2" />}
                {copiedLink ? "Copied" : "Copy Link"}
              </Button>
              <Button variant="outline" size="sm" onClick={handleShare} type="button">
                <Share2 className="w-4 h-4 mr-2" />
                Share
              </Button>
              <Button variant="destructive" size="sm" onClick={handleDelete} disabled={deleteProduct.isPending} type="button">
                <Trash className="w-4 h-4 mr-2" />
                Delete
              </Button>
            </>
          )}
          {hasUnsavedChanges && (
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={handleDiscard}
              disabled={isSaving || isUploadingAfterCreate}
              className="border-slate-300 text-slate-700 hover:bg-slate-100 cursor-pointer"
            >
              Discard Changes
            </Button>
          )}
          <Button onClick={handleSave} disabled={isSaving || isUploadingAfterCreate} size="sm">
            {isUploadingAfterCreate ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Uploading…
              </>
            ) : (
              <>
                <Save className="w-4 h-4 mr-2" />
                {isNew ? "Create" : "Save Changes"}
              </>
            )}
          </Button>
        </div>
      </div>

      {/* ── Post-create upload progress banner ── */}
      {isUploadingAfterCreate && (
        <div className="bg-indigo-50 border border-indigo-200 rounded-xl px-5 py-4 flex items-center gap-3">
          <Loader2 className="w-5 h-5 text-indigo-600 animate-spin shrink-0" />
          <div>
            <p className="text-sm font-medium text-indigo-900">Uploading photos…</p>
            <p className="text-xs text-indigo-600">
              {pendingFiles.filter((f) => f.status === "done").length} of {pendingFiles.length} done — please wait
            </p>
          </div>
        </div>
      )}

      {/* ── Retry banner (edit page — failed uploads from previous create) ── */}
      {!isNew && retryItems.length > 0 && (
        <div className="bg-amber-50 border border-amber-200 rounded-xl px-5 py-4 flex items-center gap-3">
          <AlertCircle className="w-5 h-5 text-amber-600 shrink-0" />
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-amber-900">
              {retryItems.length} photo{retryItems.length > 1 ? "s" : ""} couldn't be uploaded
            </p>
            <p className="text-xs text-amber-700 truncate">
              {retryItems.map((r) => r.name).join(", ")} — tap Re-add to try again
            </p>
          </div>
          <Button
            size="sm"
            variant="outline"
            className="shrink-0 border-amber-300 text-amber-800 hover:bg-amber-100"
            onClick={() => {
              setRetryItems([]);
              fileInputRef.current?.click();
            }}
          >
            Re-add
          </Button>
        </div>
      )}

      {/* ── Photos ── */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-semibold text-slate-900">Product Photos</h2>
            <p className="text-sm text-slate-500">
              {!isNew && orderedImages.length > 1
                ? "Drag to reorder · first photo is the storefront thumbnail"
                : "JPG, PNG, WebP · Auto-optimized for high quality"}
            </p>
          </div>
          {(!isNew || hasPendingFiles) && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => fileInputRef.current?.click()}
              disabled={isUploadingAfterCreate}
            >
              <Upload className="w-4 h-4 mr-2" />
              Add Images
            </Button>
          )}
        </div>

        {deletedImageIds.length > 0 && (
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 text-xs text-amber-800 flex items-center justify-between">
            <span>
              <strong>{deletedImageIds.length} photo{deletedImageIds.length > 1 ? "s" : ""}</strong> marked for removal. Click "Save Changes" to permanently delete or "Restore" to cancel.
            </span>
            <button
              type="button"
              onClick={() => {
                setDeletedImageIds([]);
                if (product) {
                  setOrderedImages([...product.images].sort((a, b) => a.displayOrder - b.displayOrder));
                }
                toast({ title: "Removed photos restored" });
              }}
              className="font-semibold underline text-amber-900 hover:text-amber-950 cursor-pointer ml-3 shrink-0"
            >
              Restore Photos
            </button>
          </div>
        )}

        <input
          ref={fileInputRef}
          type="file"
          accept="image/jpeg,image/png,image/webp"
          multiple
          className="hidden"
          onChange={(e) => {
            handleFilesSelected(e.target.files);
            e.target.value = "";
          }}
        />

        {isNew && !hasPendingFiles ? (
          /* Empty drop-zone for new products */
          <div
            onClick={() => fileInputRef.current?.click()}
            className="border-2 border-dashed border-slate-200 rounded-xl p-12 text-center cursor-pointer hover:border-indigo-400 hover:bg-indigo-50/50 transition-all group"
          >
            <ImageIcon className="w-10 h-10 text-slate-300 group-hover:text-indigo-400 mx-auto mb-3 transition-colors" />
            <p className="text-sm font-medium text-slate-600 group-hover:text-indigo-600 transition-colors">
              Tap to add photos
            </p>
            <p className="text-xs text-slate-400 mt-1">
              Photos will be attached when you tap Create
            </p>
          </div>
        ) : isNew && hasPendingFiles ? (
          /* Pending thumbnails on new product */
          <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-3">
            {pendingFiles.map((f) => (
              <div
                key={f.id}
                className="relative group aspect-square rounded-lg overflow-hidden border border-slate-200 bg-slate-50"
              >
                <img src={f.preview} alt={f.file.name} className="w-full h-full object-cover opacity-75" />
                <div className="absolute inset-0 flex items-center justify-center">
                  {f.status === "pending" && (
                    <div className="bg-black/40 rounded-full p-1.5">
                      <ImageIcon className="w-4 h-4 text-white" />
                    </div>
                  )}
                  {f.status === "uploading" && (
                    <Loader2 className="w-6 h-6 text-indigo-600 animate-spin drop-shadow" />
                  )}
                  {f.status === "done" && (
                    <div className="bg-green-500/80 rounded-full p-1">
                      <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                      </svg>
                    </div>
                  )}
                  {f.status === "error" && (
                    <div className="bg-red-500/80 rounded-full p-1">
                      <X className="w-4 h-4 text-white" />
                    </div>
                  )}
                </div>
                {f.status === "pending" && (
                  <button
                    onClick={() => handleRemovePendingFile(f.id)}
                    className="absolute top-1 right-1 bg-red-500 text-white rounded-full p-0.5 opacity-0 group-hover:opacity-100 transition-opacity shadow"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            ))}
            {!isUploadingAfterCreate && (
              <div
                className="aspect-square rounded-lg border-2 border-dashed border-slate-200 flex items-center justify-center cursor-pointer hover:border-indigo-300 hover:bg-indigo-50 transition-colors"
                onClick={() => fileInputRef.current?.click()}
              >
                <Upload className="w-5 h-5 text-slate-400" />
              </div>
            )}
          </div>
        ) : !hasExistingOrUploading ? (
          /* No images yet on saved product */
          <div
            className="border-2 border-dashed border-slate-200 rounded-lg p-10 text-center cursor-pointer hover:border-indigo-300 hover:bg-indigo-50 transition-colors"
            onClick={() => fileInputRef.current?.click()}
          >
            <ImageIcon className="w-8 h-8 text-slate-300 mx-auto mb-2" />
            <p className="text-sm text-slate-500">Click or drag images here</p>
          </div>
        ) : (
          /* Saved product with images — drag-to-reorder grid */
          <DndContext
            sensors={sensors}
            collisionDetection={closestCenter}
            onDragStart={() => setIsDragging(true)}
            onDragEnd={handleDragEnd}
          >
            <SortableContext
              items={orderedImages.map((img) => img.id)}
              strategy={rectSortingStrategy}
            >
              <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-3">
                {orderedImages.map((img, index) => (
                  <SortableImage
                    key={img.id}
                    img={img}
                    isPrimary={index === 0}
                    onDelete={handleDeleteImage}
                    onView={(url) => setPreviewImageUrl(url)}
                  />
                ))}

                {/* Newly added photos staged before save */}
                {pendingFiles
                  .filter((f) => f.status !== "done")
                  .map((f) => (
                  <div
                    key={f.id}
                    className="relative group aspect-square rounded-lg overflow-hidden border-2 border-dashed border-indigo-300 bg-indigo-50/40"
                  >
                    <img src={f.preview} alt={f.file.name} className="w-full h-full object-cover opacity-90" />
                    <button
                      type="button"
                      onClick={() => handleRemovePendingFile(f.id)}
                      className="absolute top-1 right-1 bg-red-500 text-white rounded-full p-1 opacity-80 hover:opacity-100 transition-opacity shadow cursor-pointer"
                      title="Remove"
                    >
                      <X className="w-3 h-3" />
                    </button>
                    <div className="absolute bottom-1 left-1 bg-indigo-600/90 text-white text-[9px] px-1.5 py-0.5 rounded font-medium">
                      Unsaved
                    </div>
                  </div>
                ))}

                {/* In-flight / error uploads */}
                {uploadingFiles.map((f) => (
                  <UploadingThumb
                    key={f.id}
                    entry={f}
                    onRetry={handleRetryUpload}
                    onDismiss={handleDismissUploadError}
                  />
                ))}

                {/* Add more button */}
                <div
                  className="aspect-square rounded-lg border-2 border-dashed border-slate-200 flex items-center justify-center cursor-pointer hover:border-indigo-300 hover:bg-indigo-50 transition-colors"
                  onClick={() => fileInputRef.current?.click()}
                >
                  <Upload className="w-5 h-5 text-slate-400" />
                </div>
              </div>
            </SortableContext>
          </DndContext>
        )}
      </div>

      {/* ── Product Details ── */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 space-y-6">
        <div className="space-y-4">
          {/* Name + Price */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>
                Item Name <span className="text-red-500">*</span>
              </Label>
              <Input
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Gold Stud Earrings"
              />
            </div>
            <div className="space-y-2">
              <Label>
                Price (₹){" "}
                <span className="text-slate-400 font-normal">(optional)</span>
              </Label>
              <Input
                type="number"
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                placeholder="Leave blank for 'Price on request'"
              />
              {!price && (
                <p className="text-xs text-slate-400">
                  Customers will see "Price on request" and can message you.
                </p>
              )}
            </div>
          </div>

          {/* Description */}
          <div className="space-y-2">
            <Label>
              Description{" "}
              <span className="text-slate-400 font-normal">(optional)</span>
            </Label>
            <Textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe the product..."
              rows={4}
            />
          </div>

          {/* Stock + Category */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>
                Stock Count{" "}
                <span className="text-slate-400 font-normal">(optional)</span>
              </Label>
              <Input
                type="number"
                value={stockCount}
                onChange={(e) => setStockCount(e.target.value)}
                placeholder="0"
              />
            </div>
            <div className="space-y-2">
              <Label>
                Categories{" "}
                <span className="text-slate-400 font-normal">(optional)</span>
              </Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    type="button"
                    className="w-full justify-between font-normal text-left bg-white border-slate-200 text-slate-900 hover:bg-slate-50"
                  >
                    <span className="truncate">
                      {categoryIds.length === 0
                        ? "Select categories"
                        : categories
                            ?.filter((c) => categoryIds.includes(c.id))
                            .map((c) => c.name)
                            .join(", ")}
                    </span>
                    <span className="text-slate-400 text-xs">▼</span>
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-[300px] p-2 bg-white border border-slate-200 rounded-md shadow-md max-h-[300px] overflow-y-auto z-[9999]" align="start">
                  {categories && categories.length > 0 ? (
                    <div className="space-y-1">
                      {categories.map((c) => {
                        const isChecked = categoryIds.includes(c.id);
                        return (
                          <div
                            key={c.id}
                            className="flex items-center space-x-2 p-2 hover:bg-slate-50 rounded-md cursor-pointer text-sm text-slate-700"
                            onClick={() => {
                              if (!isChecked) {
                                const newIds = [...categoryIds, c.id];
                                setCategoryIds(newIds);
                                if (!categoryId || categoryId === "unassigned") {
                                  setCategoryId(c.id.toString());
                                }
                              } else {
                                const updated = categoryIds.filter((id) => id !== c.id);
                                setCategoryIds(updated);
                                if (updated.length > 0) {
                                  setCategoryId(updated[0].toString());
                                } else {
                                  setCategoryId("");
                                }
                              }
                            }}
                          >
                            <Checkbox
                              checked={isChecked}
                              onCheckedChange={() => {}} // Handle inside click parent container
                            />
                            <span className="select-none">{c.name}</span>
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="text-sm text-slate-500 p-2">No categories created yet.</div>
                  )}
                </PopoverContent>
              </Popover>
            </div>
          </div>

          {/* SKU — internal only */}
          <div className="space-y-2">
            <Label>
              SKU{" "}
              <span className="text-slate-400 font-normal">(optional — internal, never shown to customers)</span>
            </Label>
            <Input
              value={sku}
              onChange={(e) => setSku(e.target.value)}
              placeholder="e.g. RING-014"
              className="font-mono"
            />
            <p className="text-xs text-slate-400">
              Your internal reference code for this item. Only visible to you in the dashboard.
            </p>
          </div>

          {/* Status (edit only) */}
          {!isNew && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 border-t border-slate-100">
              <div className="space-y-2">
                <Label>Status</Label>
                <Select value={status} onValueChange={setStatus}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="out_of_stock">Out of Stock</SelectItem>
                    <SelectItem value="hidden">Hidden</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center space-x-2 h-full pt-6">
                <Switch id="show-oos" checked={showWhenOutOfStock} onCheckedChange={setShowWhenOutOfStock} />
                <Label htmlFor="show-oos">Show when out of stock</Label>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* ── Product Variants ── */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 space-y-6">
        <div>
          <h2 className="text-base font-semibold text-slate-900">Product Variants</h2>
          <p className="text-sm text-slate-500">Enable size, color, or custom attributes for this product</p>
        </div>

        {/* Plan Upgrade Warning */}
        {!hasVariantsAccess ? (
          <div className="bg-purple-50 border border-purple-200 rounded-lg p-4 text-sm text-purple-900 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <p className="font-semibold">Variants are locked on the Starter plan</p>
              <p className="text-xs text-purple-700 mt-0.5">Upgrade to the Growth or Pro plan to configure size, color, or custom variants for your products.</p>
            </div>
            <Link href="/settings">
              <Button size="sm" className="bg-purple-600 hover:bg-purple-700 text-white shrink-0">Upgrade Plan</Button>
            </Link>
          </div>
        ) : (
          <div className="space-y-6">
            {/* Quick pre-built toggles */}
            <div className="flex flex-wrap gap-6 pt-2">
              <div className="flex items-center space-x-3">
                <Switch
                  id="variant-size"
                  checked={variants.some(v => v.variantType.toLowerCase() === "size")}
                  onCheckedChange={(checked) => {
                    if (checked) {
                      setVariants(prev => [...prev, { variantType: "Size", options: [] }]);
                    } else {
                      setVariants(prev => prev.filter(v => v.variantType.toLowerCase() !== "size"));
                    }
                  }}
                />
                <Label htmlFor="variant-size" className="font-medium cursor-pointer">Size Options</Label>
              </div>

              <div className="flex items-center space-x-3">
                <Switch
                  id="variant-color"
                  checked={variants.some(v => v.variantType.toLowerCase() === "color")}
                  onCheckedChange={(checked) => {
                    if (checked) {
                      setVariants(prev => [...prev, { variantType: "Color", options: [] }]);
                    } else {
                      setVariants(prev => prev.filter(v => v.variantType.toLowerCase() !== "color"));
                    }
                  }}
                />
                <Label htmlFor="variant-color" className="font-medium cursor-pointer">Color Options</Label>
              </div>
            </div>

            {/* List of active variants */}
            {variants.length > 0 && (
              <div className="space-y-4 pt-4 border-t border-slate-100">
                {variants.map((v, vIndex) => {
                  const isPrebuilt = v.variantType.toLowerCase() === "size" || v.variantType.toLowerCase() === "color";
                  return (
                    <div key={vIndex} className="bg-slate-50 rounded-lg p-4 border border-slate-100 relative space-y-3">
                      <div className="flex items-center justify-between">
                        {isPrebuilt ? (
                          <span className="text-sm font-semibold text-slate-800">{v.variantType}</span>
                        ) : (
                          <div className="flex items-center gap-2 max-w-xs">
                            <Label className="text-xs text-slate-500 shrink-0">Variant Name:</Label>
                            <Input
                              size={20}
                              value={v.variantType}
                              placeholder="e.g. Material"
                              className="h-8 py-1 text-sm bg-white"
                              onChange={(e) => {
                                const val = e.target.value;
                                setVariants(prev => prev.map((item, idx) => idx === vIndex ? { ...item, variantType: val } : item));
                              }}
                            />
                          </div>
                        )}
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-7 w-7 text-slate-400 hover:text-red-500 absolute top-2 right-2"
                          onClick={() => {
                            setVariants(prev => prev.filter((_, idx) => idx !== vIndex));
                          }}
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </div>

                      {/* Options tags editor */}
                      <div className="space-y-2">
                        <Label className="text-xs text-slate-500">Options:</Label>
                        <div className="flex flex-wrap gap-1.5 min-h-8 p-2 rounded-md bg-white border border-slate-200">
                          {v.options.map((opt, oIdx) => (
                            <div key={opt} className="inline-flex items-center gap-1 bg-indigo-50 border border-indigo-200 text-indigo-800 text-xs px-2 py-0.5 rounded-full font-medium">
                              <span>{opt}</span>
                              <button
                                type="button"
                                className="text-indigo-400 hover:text-indigo-600 focus:outline-none"
                                onClick={() => {
                                  setVariants(prev => prev.map((item, idx) => idx === vIndex ? { ...item, options: item.options.filter((_, o) => o !== oIdx) } : item));
                                }}
                              >
                                <X className="w-3 h-3" />
                              </button>
                            </div>
                          ))}
                          <input
                            type="text"
                            placeholder={v.options.length === 0 ? "Type option and press Enter (e.g. S, M, L)" : "Add option..."}
                            className="flex-1 min-w-[120px] outline-none text-xs text-slate-800 bg-transparent"
                            onKeyDown={(e) => {
                              if (e.key === "Enter") {
                                e.preventDefault();
                                const val = e.currentTarget.value.trim();
                                if (val && !v.options.includes(val)) {
                                  setVariants(prev => prev.map((item, idx) => idx === vIndex ? { ...item, options: [...item.options, val] } : item));
                                  e.currentTarget.value = "";
                                }
                              }
                            }}
                            onBlur={(e) => {
                              const val = e.target.value.trim();
                              if (val && !v.options.includes(val)) {
                                setVariants(prev => prev.map((item, idx) => idx === vIndex ? { ...item, options: [...item.options, val] } : item));
                                e.target.value = "";
                              }
                            }}
                          />
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            <Button
              type="button"
              variant="outline"
              size="sm"
              className="border-dashed"
              onClick={() => {
                setVariants(prev => [...prev, { variantType: "", options: [] }]);
              }}
            >
              Add Custom Variant
            </Button>
          </div>
        )}
      </div>

      {/* ── Bottom Floating / Sticky Action Bar ── */}
      <div className="sticky bottom-4 z-20 bg-white/95 backdrop-blur border border-slate-200 shadow-lg rounded-xl p-4 flex items-center justify-between gap-4 mt-8">
        <div className="text-sm text-slate-500">
          {hasUnsavedChanges ? (
            <span className="flex items-center text-amber-600 font-medium">
              <span className="w-2 h-2 rounded-full bg-amber-500 mr-2 animate-pulse" />
              Unsaved changes
            </span>
          ) : (
            <span className="text-slate-400">All changes saved</span>
          )}
        </div>
        <div className="flex items-center gap-3">
          {hasUnsavedChanges && (
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={handleDiscard}
              disabled={isSaving || isUploadingAfterCreate}
              className="border-slate-300 text-slate-700 hover:bg-slate-100 cursor-pointer"
            >
              Discard Changes
            </Button>
          )}
          <Button onClick={handleSave} disabled={isSaving || isUploadingAfterCreate} size="sm">
            {isUploadingAfterCreate ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Uploading…
              </>
            ) : (
              <>
                <Save className="w-4 h-4 mr-2" />
                {isNew ? "Create Product" : "Save Changes"}
              </>
            )}
          </Button>
        </div>
      </div>

      {previewImageUrl && (
        <ImageLightbox
          src={previewImageUrl}
          alt="Full size product view"
          onClose={() => setPreviewImageUrl(null)}
        />
      )}
    </div>
  );
}
